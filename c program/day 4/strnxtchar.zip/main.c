#include <stdio.h>
#include <ctype.h>

int main() {
    char str[] = "BcD@eF#";
    int i = 0;

    while (str[i] != '\0') {
        if (isalpha(str[i])) {
           
            str[i] = str[i] + 1;
        }
       
        i++;
    }

    printf("Output: %s\n", str);
    return(0);
}