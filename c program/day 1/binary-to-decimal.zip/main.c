

#include <stdio.h>

int main()
{
    int a=1011;
    int count=0;
    int sum=0;
    int sum1=0;
 
   while (a>0)
    {
       count=count+1;
        if (sum>=0)
        {
            sum=(sum+(a%10))*10;
            a=a/10;
            
        }
    }
    sum=sum/10
    for (int i=0;i<count;i++)
    {
        printf("%d",(sum%10)*2^i);
        //printf("%d",i);
        //sum1=sum1+((sum%10)*2^i);
        //printf("%d \n",sum1);
    }
    printf("%d \n",sum);
    
    //printf("%d\n",count);
    //printf("%d\n",sum1);
    return 0;
}